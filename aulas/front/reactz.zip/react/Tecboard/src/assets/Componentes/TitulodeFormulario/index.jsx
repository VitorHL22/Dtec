import '../TitulodeFormulario/TitulodeFormulario.css'

export function TituloFormulario(props) {
  return (
    <h2>{props.children}</h2>
  )
} 