import './CampoDeEntrada.css'

export function CampoDeEntrada(props) {
  return <input {...props}
  className='campo-entrada-form'/>
}